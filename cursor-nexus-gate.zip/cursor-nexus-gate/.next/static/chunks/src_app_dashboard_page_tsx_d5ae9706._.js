(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_4620a03d._.js",
  "static/chunks/node_modules_@fortawesome_free-solid-svg-icons_index_mjs_6d4e8d45._.js",
  "static/chunks/node_modules_69fd3a8b._.js",
  "static/chunks/src_app_dashboard_20f6e0ee._.js"
],
    source: "dynamic"
});
