(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_antd_es_4e70e352._.js",
  "static/chunks/node_modules_@ant-design_cssinjs_es_b0712784._.js",
  "static/chunks/node_modules_rc-menu_es_d0fe5480._.js",
  "static/chunks/node_modules_rc-field-form_es_4fb5d7cb._.js",
  "static/chunks/node_modules_ffb5ee68._.js",
  "static/chunks/_7fb7d387._.js"
],
    source: "dynamic"
});
