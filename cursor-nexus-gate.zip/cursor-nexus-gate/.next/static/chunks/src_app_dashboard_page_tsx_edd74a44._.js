(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a8d8ea3e._.js",
  "static/chunks/src_app_dashboard_653f9075._.js",
  "static/chunks/node_modules_swiper_62da158d._.css"
],
    source: "dynamic"
});
