(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_4898c2a4._.js",
  "static/chunks/src_d27bb62e._.js",
  "static/chunks/_6ec3a835._.css"
],
    source: "dynamic"
});
