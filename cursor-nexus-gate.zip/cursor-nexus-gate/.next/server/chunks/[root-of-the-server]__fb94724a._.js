module.exports = {

"[project]/.next-internal/server/app/api/home/cards/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/api/home/cards/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
async function POST(request) {
    const body = await request.json();
    const { scene } = body;
    const data = [
        {
            "id": 1,
            "color": "bg-blue-500",
            "title": "服务器状态",
            "url": "https://chat.deepseek.com/a/chat/s/8ee3230c-f28b-4862-b26b-fa0583f4c53e",
            "content": "所有服务器运行正常，负载率低于30%"
        },
        {
            "id": 2,
            "color": "bg-green-500",
            "title": "用户活跃度",
            "url": "https://chat.deepseek.com/a/chat/s/8ee3230c-f28b-4862-b26b-fa0583f4c53e",
            "content": "今日活跃用户1,284人，较昨日增长12%"
        },
        {
            "id": 3,
            "color": "bg-yellow-500",
            "title": "待处理任务",
            "url": "https://chat.deepseek.com/a/chat/s/8ee3230c-f28b-4862-b26b-fa0583f4c53e",
            "content": "当前有15项任务待处理，建议优先处理高优先级事项"
        },
        {
            "id": 4,
            "color": "bg-purple-500",
            "title": "系统通知",
            "url": "https://chat.deepseek.com/a/chat/s/8ee3230c-f28b-4862-b26b-fa0583f4c53e",
            "content": "检测到3个系统更新，点击查看详情"
        },
        {
            "id": 5,
            "color": "bg-red-500",
            "title": "告警信息",
            "url": "https://chat.deepseek.com/a/chat/s/8ee3230c-f28b-4862-b26b-fa0583f4c53e",
            "content": "数据库连接数接近上限，建议优化查询性能"
        }
    ];
    // 模拟接口校验
    if (scene == 1) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            message: '查询成功',
            data
        });
    } else {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: '暂无有效数据'
        }, {
            status: 401
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__fb94724a._.js.map