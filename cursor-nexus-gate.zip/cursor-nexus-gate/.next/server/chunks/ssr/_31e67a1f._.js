module.exports = {

"[project]/.next-internal/server/app/dashboard/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/app/dashboard/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/dashboard/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/app/dashboard/[id]/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-rsc] (ecmascript)");
;
// 模拟卡片数据（实际项目中可替换为数据库查询）
const mockCards = [
    {
        id: '1',
        title: '服务器状态监控',
        description: '实时监控服务器CPU、内存、磁盘使用率，当指标超过阈值时自动发送告警通知',
        color: 'bg-blue-500',
        content: '所有服务器运行正常，负载率低于30%'
    },
    {
        id: '2',
        title: '用户活跃度分析',
        description: '统计每日/每周/每月活跃用户数，分析用户增长趋势和留存率',
        color: 'bg-green-500',
        content: '今日活跃用户1,284人，较昨日增长12%'
    },
    {
        id: '3',
        title: '任务管理中心',
        description: '集中管理系统内所有待处理任务，支持优先级排序和分配功能',
        color: 'bg-yellow-500',
        content: '当前有15项任务待处理，建议优先处理高优先级事项'
    }
];
async function GET(request, { params }) {
    try {
        // 1. 获取并验证ID参数
        const { id } = params;
        if (!id || typeof id !== 'string') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: '无效的请求参数',
                details: 'ID必须是有效的字符串'
            }, {
                status: 400
            } // 400 Bad Request
            );
        }
        // 2. 查询数据（实际项目中替换为数据库操作）
        const card = mockCards.find((item)=>item.id === id);
        // 3. 处理数据不存在的情况
        if (!card) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: '数据不存在',
                details: `未找到ID为${id}的卡片`
            }, {
                status: 404
            } // 404 Not Found
            );
        }
        // 4. 返回成功响应（确保为JSON格式）
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: card
        });
    } catch (error) {
        // 5. 统一捕获服务器错误，返回JSON格式的错误信息
        console.error('API请求错误:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: '服务器内部错误',
            // 开发环境返回详细错误信息，生产环境隐藏
            details: ("TURBOPACK compile-time truthy", 1) ? error.message : ("TURBOPACK unreachable", undefined)
        }, {
            status: 500
        } // 500 Internal Server Error
        );
    }
}
}}),
"[project]/src/app/dashboard/[id]/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/dashboard/[id]/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_31e67a1f._.js.map