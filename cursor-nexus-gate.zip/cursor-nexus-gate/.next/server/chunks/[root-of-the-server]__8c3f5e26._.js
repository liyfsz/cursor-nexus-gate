module.exports = {

"[project]/.next-internal/server/app/api/card/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/mock/data.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// lib/data.ts
__turbopack_context__.s({
    "getDashboardItems": (()=>getDashboardItems),
    "getItemById": (()=>getItemById),
    "items": (()=>items)
});
const items = [
    {
        id: 'element-001',
        name: '用户管理按钮',
        type: 'Button',
        module: '用户管理',
        description: '用于跳转用户列表页面的按钮',
        status: 'active',
        createTime: '2024-05-12 10:20:00',
        updateTime: '2024-06-01 14:30:00',
        permissions: [
            'user:view'
        ],
        metadata: {
            icon: 'user',
            color: '#409EFF',
            position: 'top-right',
            visible: true
        }
    },
    {
        id: 'element-002',
        name: '系统设置表单',
        type: 'Form',
        module: '系统设置',
        description: '编辑系统参数的表单区域',
        status: 'inactive',
        createTime: '2024-03-21 08:15:00',
        updateTime: '2024-04-10 11:40:00',
        permissions: [
            'system:edit'
        ],
        metadata: {
            fields: [
                'siteName',
                'maxUploadSize',
                'enableFeatureX'
            ],
            autosave: true,
            validation: true
        }
    },
    {
        id: 'element-003',
        name: '服务器监控图表',
        type: 'Chart',
        module: '运维中心',
        description: '展示 CPU、内存等指标的图表组件',
        status: 'active',
        createTime: '2024-01-05 09:00:00',
        updateTime: '2024-05-17 17:22:00',
        permissions: [
            'monitor:view'
        ],
        metadata: {
            chartType: 'line',
            interval: '5min',
            dataSources: [
                'cpu',
                'memory',
                'disk'
            ]
        }
    }
];
function getDashboardItems({ page = 1, pageSize = 3 }) {
    const start = (page - 1) * pageSize;
    return items.slice(start, start + pageSize);
}
function getItemById(id) {
    console.log(id, 'id');
    return items.find((item)=>item.id == id);
}
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/api/card/[id]/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// app/api/card/[id]/route.ts
__turbopack_context__.s({
    "GET": (()=>GET),
    "dynamic": (()=>dynamic)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mock$2f$data$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/mock/data.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
;
const dynamic = 'force-dynamic';
// 模拟卡片数据
const mockCards = [
    {
        id: '1',
        title: '服务器状态监控',
        description: '实时监控服务器CPU、内存、磁盘使用率'
    },
    {
        id: '2',
        title: '用户活跃度分析',
        description: '统计活跃用户数，分析增长趋势'
    },
    {
        id: '3',
        title: '任务管理中心',
        description: '集中管理系统内所有待处理任务'
    }
];
async function GET(request, { params }) {
    console.log('接收到的 params.id:', params.id);
    try {
        console.log('[id]');
        const { id } = params;
        if (!id || typeof id !== 'string') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: '无效的请求参数',
                details: 'ID必须是字符串'
            }, {
                status: 400
            });
        }
        const card = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mock$2f$data$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getItemById"])(id);
        if (!card) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: '未找到对应卡片',
                details: `ID = ${id}`
            }, {
                status: 404
            });
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: card
        });
    } catch (err) {
        console.error('API 错误:', err);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: '服务器内部错误'
        }, {
            status: 500
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__8c3f5e26._.js.map