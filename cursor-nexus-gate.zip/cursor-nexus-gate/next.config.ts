import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  // next.config.js 中可配置 rewrites,仅限！！！本地！！！！
  async rewrites() {
    return [
      // {
      //   source: '/api/:path*',
      //   destination: 'https://api.your-service.com/:path*', // 远程代理todo
      // },
      // {
      //   source: '/api/:path*',
      //   destination: 'http://localhost:3000/api/:path*', // 本地 mock;使用api模拟会影响动态接口返回
      // }
    ]
  }

};

export default nextConfig;
