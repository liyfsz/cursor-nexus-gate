// app/api/dashboard/route.ts
import { NextResponse } from 'next/server'
import { getDashboardItems } from '@/mock/data'

export async function POST(req: Request) {
  const body = await req.json()
  const { page = 1, pageSize = 3 } = body
  console.log('page', page)
  const data = getDashboardItems({ page, pageSize })

  return NextResponse.json({
    data,
    page,
    pageSize,
    total: 5, // 总数写死（真实项目应该从数据库查）
  })
}
