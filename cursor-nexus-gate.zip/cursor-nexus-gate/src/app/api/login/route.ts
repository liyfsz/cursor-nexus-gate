import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  const body = await request.json();
  const { username, password } = body;
  // 模拟接口校验
  if (username === 'admin' && password === 'password') {
    return NextResponse.json({ success: true, message: '登录成功123' });
  } else {
    return NextResponse.json({ success: false, message: '用户名或密码错误' }, { status: 401 });
  }
//   try {
//     const response = await fetch('https://qdcs.hrbbcf.com/midEndService/login', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({ username, password }),
//     });
//     const data = await response.json();
//     return NextResponse.json(data);
//   } catch (error) {
//     return NextResponse.json({ success: false, message: '登录失败，请重试' }, { status: 500 });
//   }
}