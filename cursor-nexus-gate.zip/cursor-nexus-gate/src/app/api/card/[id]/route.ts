// app/api/card/[id]/route.ts
import { getItemById } from '@/mock/data';
import { NextResponse } from 'next/server'
export const dynamic = 'force-dynamic';
// 模拟卡片数据
const mockCards = [
    {
        id: '1',
        title: '服务器状态监控',
        description: '实时监控服务器CPU、内存、磁盘使用率',
    },
    {
        id: '2',
        title: '用户活跃度分析',
        description: '统计活跃用户数，分析增长趋势',
    },
    {
        id: '3',
        title: '任务管理中心',
        description: '集中管理系统内所有待处理任务',
    },
]

export async function GET(
    request: Request,
    { params }: { params: { id: string } }
) {
    console.log('接收到的 params.id:', params.id)
    try {
        console.log('[id]')
        const { id } = params

        if (!id || typeof id !== 'string') {
            return NextResponse.json(
                { error: '无效的请求参数', details: 'ID必须是字符串' },
                { status: 400 }
            )
        }

        const card = getItemById(id)

        if (!card) {
            return NextResponse.json(
                { error: '未找到对应卡片', details: `ID = ${id}` },
                { status: 404 }
            )
        }

        return NextResponse.json({ success: true, data: card })
    } catch (err) {
        console.error('API 错误:', err)
        return NextResponse.json(
            {
                error: '服务器内部错误',
            },
            { status: 500 }
        )
    }
}
