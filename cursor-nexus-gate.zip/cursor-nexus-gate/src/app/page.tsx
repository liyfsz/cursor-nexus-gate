'use client';

import Menu from '../components/SidebarMenu';
import Header from '../components/Header';

export default function Home() {

  return (
    <div className="flex flex-col h-screen">
      {/* 头部导航条 */}
      <Header />

      <div className="flex flex-1">
        {/* 左侧菜单 */}
        <Menu />

        {/* 主内容区域 */}
        <main className="flex-1 p-4">
          首页还没想好，敬请期待...
        </main>
      </div>
    </div>
  );
}