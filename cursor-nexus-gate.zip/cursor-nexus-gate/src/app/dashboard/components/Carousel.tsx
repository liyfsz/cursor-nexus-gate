'use client'

import { Swiper, SwiperSlide } from 'swiper/react'
import { Navigation, Autoplay } from 'swiper/modules'
import { Card, Tag, Tooltip } from 'antd'
import Link from 'next/link'

import 'swiper/css'
import 'swiper/css/navigation'
import styles from './index.module.css'

interface ElementItem {
  id: string
  name: string
  type: string
  module: string
  description: string
  status: 'active' | 'inactive'
}

interface CarouselProps {
  items: ElementItem[]
}

export default function Carousel({ items }: CarouselProps) {
  const renderStatus = (status: ElementItem['status']) => (
    <Tag color={status === 'active' ? 'green' : 'red'}>
      {status === 'active' ? '启用' : '停用'}
    </Tag>
  )

  return (
    <div className={`w-full ${styles.carouselWrapper}`}>
      <Swiper
        modules={[Navigation, Autoplay]}
        navigation
        autoplay={{ delay: 3000 }}
        loop
        breakpoints={{
          640: { slidesPerView: 1, spaceBetween: 16 },
          1024: { slidesPerView: 2, spaceBetween: 20 },
          1440: { slidesPerView: 3, spaceBetween: 24 }
        }}
      >
        {items.map((item) => (
          <SwiperSlide key={item.id}>
            <Link href={`/dashboard/${item.id}`} passHref>
              <Card
                hoverable
                title={item.name}
                extra={renderStatus(item.status)}
                className="h-full"
                style={{ width: '100%', cursor: 'pointer' }}
              >
                <p><strong>模块：</strong>{item.module}</p>
                <p><strong>类型：</strong>{item.type}</p>
                <Tooltip title={item.description}>
                  <p className="truncate"><strong>描述：</strong>{item.description}</p>
                </Tooltip>
              </Card>
            </Link>
          </SwiperSlide>
        ))}
      </Swiper>

    </div>
  )
}

