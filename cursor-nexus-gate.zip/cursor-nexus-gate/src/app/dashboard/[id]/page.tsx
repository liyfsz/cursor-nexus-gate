'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'

interface CardItem {
    id: string
    title: string
    description: string
}

export default function DetailPage() {
    const params = useParams()
    const [item, setItem] = useState<CardItem | null>(null)
    const [error, setError] = useState<string | null>(null)

    useEffect(() => {

        const fetchData = async () => {
            if (!params.id) return;
            try {
                const response = await fetch(`/api/card/${params.id}`);
                const data = await response.json()
                console.log('response', data.data)
                setItem(data.data)
            } catch (err) {
                console.error('解析或请求出错:', err)
                setError('网络错误或服务器异常')
            }
        }

        fetchData()
    }, [params.id])

    if (error) return <div>❌ 错误: {error}</div>
    if (!item) return <div>加载中...</div>

    return (
        <div>
            <h1>{item.title}</h1>
            <p>{item.description}</p>
        </div>
    )
}
