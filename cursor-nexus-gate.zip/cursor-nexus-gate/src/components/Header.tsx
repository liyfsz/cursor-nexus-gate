'use client';

import { useEffect, useState } from "react";

const Header = () => {
    const [username, setUsername] = useState('');

    useEffect(() => {
        const isLoggedIn = localStorage.getItem('isLoggedIn');
        if (!isLoggedIn) {
            window.location.href = '/login';
        } else {
            setUsername('admin');
        }
    }, []);
    return <>
        <header className="bg-blue-600 text-white p-4 flex justify-between items-center">
            <div className="text-xl font-bold">XXX系统</div>
            <div>欢迎，{username}</div>
        </header>
    </>
}

export default Header