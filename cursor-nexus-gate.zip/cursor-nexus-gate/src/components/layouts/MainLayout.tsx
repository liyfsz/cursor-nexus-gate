// src/components/layouts/MainLayout.tsx
'use client'

import SidebarMenu from "@/components/SidebarMenu"
import Header from "@/components/Header"

export default function MainLayout({
    children,
}: {
    children: React.ReactNode
}) {
    return (
        <div className="flex flex-col h-screen">
            {/* 头部导航条 */}
            <Header />

            <div className="flex flex-1">
                {/* 左侧菜单 */}
                <SidebarMenu />

                {/* 主内容区域 */}
                <main className="flex-1 p-4">
                    {children}
                </main>
            </div>
        </div>
    )
}
