// lib/dashboard.ts
import { apiClient } from './apiClient'

export type DashboardItem = {
    id: string
    title: string
    description: string
}

export async function fetchDashboardItems({
    page = 1,
    pageSize = 3,
}: {
    page?: number
    pageSize?: number
}): Promise<DashboardItem[]> {
    const res = await apiClient.post<{ data: DashboardItem[] }>(
        '/api/dashboard',
        { page, pageSize }
    )
    return res.data
}
