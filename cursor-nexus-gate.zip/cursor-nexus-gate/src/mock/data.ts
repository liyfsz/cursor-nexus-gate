// lib/data.ts
export const items = [
    {
        id: 'element-001',
        name: '用户管理按钮',
        type: 'Button',
        module: '用户管理',
        description: '用于跳转用户列表页面的按钮',
        status: 'active',
        createTime: '2024-05-12 10:20:00',
        updateTime: '2024-06-01 14:30:00',
        permissions: ['user:view'],
        metadata: {
            icon: 'user',
            color: '#409EFF',
            position: 'top-right',
            visible: true,
        },
    },
    {
        id: 'element-002',
        name: '系统设置表单',
        type: 'Form',
        module: '系统设置',
        description: '编辑系统参数的表单区域',
        status: 'inactive',
        createTime: '2024-03-21 08:15:00',
        updateTime: '2024-04-10 11:40:00',
        permissions: ['system:edit'],
        metadata: {
            fields: ['siteName', 'maxUploadSize', 'enableFeatureX'],
            autosave: true,
            validation: true,
        },
    },
    {
        id: 'element-003',
        name: '服务器监控图表',
        type: 'Chart',
        module: '运维中心',
        description: '展示 CPU、内存等指标的图表组件',
        status: 'active',
        createTime: '2024-01-05 09:00:00',
        updateTime: '2024-05-17 17:22:00',
        permissions: ['monitor:view'],
        metadata: {
            chartType: 'line',
            interval: '5min',
            dataSources: ['cpu', 'memory', 'disk'],
        },
    },

]
// 模拟分页或过滤
export function getDashboardItems({ page = 1, pageSize = 3 }) {
    const start = (page - 1) * pageSize
    return items.slice(start, start + pageSize)
}

//卡片详情
export function getItemById(id: string) {
    console.log(id, 'id');
    return items.find(item => item.id == id)
}

